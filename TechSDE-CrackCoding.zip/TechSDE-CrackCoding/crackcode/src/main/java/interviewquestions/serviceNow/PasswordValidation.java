package interviewquestions.serviceNow;

public class PasswordValidation {
  public static boolean isValidPassword(String password){

    return false;
  }
}
