package stack;

public class StackNode {
    int data;
    StackNode next;

    StackNode(int d) {
        this.data = d;
        this.next = null;
    }
}
