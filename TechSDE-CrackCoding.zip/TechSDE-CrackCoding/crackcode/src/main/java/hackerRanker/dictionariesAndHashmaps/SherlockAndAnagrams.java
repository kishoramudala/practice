package hackerRanker.dictionariesAndHashmaps;

public class SherlockAndAnagrams {

    static int sherlockAndAnagrams(String s) {

        return 1;
    }
}
